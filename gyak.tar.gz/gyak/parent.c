#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include<sys/wait.h>

int main () {
pid_t cpid;
   if (fork() == 0) {
   	char command[50];

   strcpy( command, "./child" );
        system(command);
    exit(0);
    }
else  cpid = wait(NULL);
   return(0);
} 
