#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main () {
   char command[50];

   strcpy( command, "date" );
   system(command);
   strcpy( command, "date -n" );
   system(command);

   return(0);
} 
