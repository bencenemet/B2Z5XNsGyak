#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main () {
   char command[40];
	
	scanf("%s",command);
	system(command);

   return(0);
} 
