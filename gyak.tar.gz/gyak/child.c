#include <string.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdio.h>

int main () {
   for (int i=0; i<10; i++) {
   printf("%d. Nemet Bence - B2Z5XN\n",i+1);
   }

   return(0);
} 
