#include <stdio.h>
#include <unistd.h>

int main(){     
     int p, f;  
     int rw_setup[2];   
     char message[20];      
     p = pipe(rw_setup);    
     if(p < 0){         
        printf("An error occured. Could not create the pipe.");  
        _exit(1);   
     }      
     f = fork();    
     if(f > 0){
        write(rw_setup[1], "Pazmany Laszlo",15);    
     }  
     else if(f == 0){       
        read(rw_setup[0],message,15);       
        printf("%s\n", message);   
     }  
     else{      
        printf("Could not create the child process");   
     }      
     return 0;

}
