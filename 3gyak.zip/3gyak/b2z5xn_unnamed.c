#include <unistd.h>  
#include <stdio.h>
#include <string.h>
#include <wait.h>  

#define MaxLen 80
#define PipeStdIn   0    
#define PipeStdOut  1   

int main( ) {
  int ret, myPipes[2];
  char buff[MaxLen + 1];

  if( pipe( myPipes ) == 0 ){

       if( fork( ) == 0 ) {

          char *reply = {"Pazmany Laszlo F0F7F6.\n"};


          close(myPipes[PipeStdIn]); // CLOSE BEFORE WRITE
          write( myPipes[PipeStdOut], reply, strlen(reply) + 1); 


   } 
   else { 

          close(myPipes[PipeStdOut]); // CLOSE BEFORE READ
          read(myPipes[PipeStdIn], buff, MaxLen); 
          printf("Parent receives message: %s", buff);

          
   }
 }
  return 0; 
 }
